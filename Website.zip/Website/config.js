// config.js
module.exports = {
    db: {
      host: 'localhost',  // MySQL host
      user: 'root',       // Your MySQL username
      password: '3185',       // Your MySQL password
      database: 'holontelecomdb', // Replace with your database name
    },
    email: {
      service: 'gmail', // Replace with your email service (if using Gmail)
      auth: {
        user: 'holontelecom@gmail.com', // Your email address
        pass: 'qweqwe123', // Your email password
      }
    }
  };
  